"""
This is a boilerplate pipeline 'data_prep'
generated using Kedro 0.18.11
"""

from kedro.pipeline import node, pipeline

from .nodes import (
    create_model_input_table,
    get_data,
    preprocess_companies,
    preprocess_shuttles,
)


def create_pipeline(**kwargs) -> pipeline:
    return pipeline(
        [
            node(
                func=get_data,
                inputs=None,
                outputs=["companies", "shuttles", "reviews"],
                name="getdata",
            ),
            node(
                func=preprocess_companies,
                inputs="companies",
                outputs="companies_proc",
                name="preprocesscompanies",
            ),
            node(
                func=preprocess_shuttles,
                inputs="shuttles",
                outputs="shuttles_proc",
                name="preprocessshuttles",
            ),
            node(
                func=create_model_input_table,
                inputs=["shuttles_proc", "companies_proc", "reviews"],
                outputs="model_input_table",
                name="createmodelinputtable",
            ),
        ]
    )
